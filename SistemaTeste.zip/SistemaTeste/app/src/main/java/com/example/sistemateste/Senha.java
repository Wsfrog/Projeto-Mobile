// com/example/sistemateste/Senha.java
package com.example.sistemateste;

public class Senha {
    private int id;
    private String nome;
    private String senha;
    private String usuarioEmail;

    public Senha(int id, String nome, String senha, String usuarioEmail) {
        this.id = id;
        this.nome = nome;
        this.senha = senha;
        this.usuarioEmail = usuarioEmail;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getSenha() { return senha; }
    public String getUsuarioEmail() { return usuarioEmail; }

    public void setSenha(String senha) { this.senha = senha; }
}
