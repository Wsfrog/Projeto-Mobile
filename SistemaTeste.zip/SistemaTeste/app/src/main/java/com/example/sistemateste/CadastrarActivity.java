package com.example.sistemateste;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastrarActivity extends AppCompatActivity {

    BancoDAO banco;
    EditText entradaNome, entradaEmail, entradaSenha;
    Button botaoCadastrar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastrar); // Seu layout do cadastro

        banco = new BancoDAO(this);

        entradaNome = findViewById(R.id.entrada_nome);
        entradaEmail = findViewById(R.id.entrada_email);
        entradaSenha = findViewById(R.id.entrada_senha);
        botaoCadastrar = findViewById(R.id.botao_cadastrar);

        botaoCadastrar.setOnClickListener(view -> {
            String nome = entradaNome.getText().toString().trim();
            String email = entradaEmail.getText().toString().trim();
            String senha = entradaSenha.getText().toString().trim();

            if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha nome, email e senha", Toast.LENGTH_SHORT).show();
                return;
            }

            // Como id é autogerado no banco, use 0 aqui
            Usuario novoUsuario = new Usuario(0, nome, email, senha);
            boolean sucesso = banco.cadastrarUsuario(novoUsuario);

            if (sucesso) {
                Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                finish(); // fecha tela de cadastro e volta para o login
            } else {
                Toast.makeText(this, "Erro ao cadastrar. Email pode já estar em uso.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
