// com/example/sistemateste/BancoDAO.java
package com.example.sistemateste;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class BancoDAO extends SQLiteOpenHelper {

    private static final String NOME_BANCO = "bd_sistema_teste.db";
    private static final int VERSAO_BANCO = 2;  // ou a versão que você já estiver usando

    public BancoDAO(Context context) {
        super(context, NOME_BANCO, null, VERSAO_BANCO);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Habilita uso de FOREIGN KEY (caso tenha tabelas com relacionamento)
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Cria tabela 'usuarios' (id + nome + email + senha)
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS usuarios (" +
                        "  id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "  nome TEXT    NOT NULL, " +
                        "  email TEXT   UNIQUE NOT NULL, " +
                        "  senha TEXT   NOT NULL" +
                        ");"
        );

        // Exemplo de outra tabela com FK (senhas), não obrigatória para o perfil,
        // mas mantida aqui caso você já tenha em uso:
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS senhas (" +
                        "  id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "  nome TEXT    NOT NULL, " +
                        "  senha TEXT   NOT NULL, " +
                        "  usuarioEmail TEXT NOT NULL, " +
                        "  FOREIGN KEY (usuarioEmail) REFERENCES usuarios(email) ON DELETE CASCADE" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Exemplo simplificado: ao aumentar versão, derruba tabelas antigas e recria.
        db.execSQL("DROP TABLE IF EXISTS senhas;");
        db.execSQL("DROP TABLE IF EXISTS usuarios;");
        onCreate(db);
    }

    // ===========================
    // MÉTODOS EXISTENTES (já funcionando)
    // ===========================

    /**
     * Cadastra um novo usuário. Retorna true se gravou com sucesso.
     */
    public boolean cadastrarUsuario(Usuario usuario) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", usuario.getNome());
        cv.put("email", usuario.getEmail());
        cv.put("senha", usuario.getSenha());

        long resultado = -1;
        try {
            resultado = db.insertOrThrow("usuarios", null, cv);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado != -1;
    }

    /**
     * Autentica usuário. Retorna true se existir um registro com email+senha.
     */
    public boolean autenticarUsuario(String email, String senha) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM usuarios WHERE email = ? AND senha = ?",
                new String[]{email, senha}
        );
        boolean existe = cursor.moveToFirst();
        cursor.close();
        return existe;
    }

    /**
     * Lista todas as senhas gravadas para um dado usuário (referência à tabela 'senhas').
     */
    public List<Senha> listarSenhas(String usuarioEmail) {
        List<Senha> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                "senhas",
                new String[]{"id", "nome", "senha", "usuarioEmail"},
                "usuarioEmail = ?",
                new String[]{usuarioEmail},
                null, null, "nome ASC"
        );

        while (cursor.moveToNext()) {
            lista.add(new Senha(
                    cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("nome")),
                    cursor.getString(cursor.getColumnIndexOrThrow("senha")),
                    cursor.getString(cursor.getColumnIndexOrThrow("usuarioEmail"))
            ));
        }
        cursor.close();
        return lista;
    }

    public boolean inserirSenha(Senha senhaObj) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", senhaObj.getNome());
        cv.put("senha", senhaObj.getSenha());
        cv.put("usuarioEmail", senhaObj.getUsuarioEmail());

        long resultado = db.insert("senhas", null, cv);
        return resultado != -1;
    }

    public boolean atualizarSenha(int id, String novaSenha) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("senha", novaSenha);
        return db.update("senhas", cv, "id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deletarSenha(int id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("senhas", "id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    // ===========================
    // NOVOS MÉTODOS PARA PERFIL
    // ===========================

    /**
     * Busca um usuário pelo email e retorna um objeto Usuario com todos os dados (incluindo senha).
     * Retorna null se não encontrar.
     */
    public Usuario buscarUsuario(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT id, nome, email, senha FROM usuarios WHERE email = ?",
                new String[]{email}
        );

        Usuario usuario = null;
        if (cursor.moveToFirst()) {
            int    id    = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String nome  = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
            String usuEmail = cursor.getString(cursor.getColumnIndexOrThrow("email"));
            String senha = cursor.getString(cursor.getColumnIndexOrThrow("senha"));
            usuario = new Usuario(id, nome, usuEmail, senha);
        }
        cursor.close();
        return usuario;
    }

    /**
     * Atualiza os dados (nome, email e senha) de um usuário já existente.
     * Retorna true se ao menos uma linha for alterada.
     */
    public boolean atualizarUsuario(String emailAntigo, String novoNome, String novoEmail, String novaSenha) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", novoNome);
        cv.put("email", novoEmail);
        cv.put("senha", novaSenha);
        int linhas = db.update("usuarios", cv, "email = ?", new String[]{emailAntigo});
        return linhas > 0;
    }

    /**
     * Deleta o usuário cujo email foi informado. Com ON DELETE CASCADE, senhas também caem.
     */
    public boolean deletarUsuario(String email) {
        SQLiteDatabase db = getWritableDatabase();
        int linhas = db.delete("usuarios", "email = ?", new String[]{email});
        return linhas > 0;
    }
}
