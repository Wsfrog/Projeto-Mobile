package com.example.sistemateste;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class SenhaActivity extends AppCompatActivity {

    private BancoDAO bancoDAO;
    private LinearLayout containerCards;
    private FloatingActionButton botaoAdicionar;
    private String usuarioEmailLogado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ===> Bloqueia screenshot e gravação de vídeo nesta Activity <===
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_senhas);

        bancoDAO        = new BancoDAO(this);
        containerCards  = findViewById(R.id.container_cards);
        botaoAdicionar  = findViewById(R.id.botao_adicionar);

        usuarioEmailLogado = getIntent().getStringExtra("emailUsuario");
        if (usuarioEmailLogado == null || usuarioEmailLogado.isEmpty()) {
            Toast.makeText(this, "Erro: usuário não identificado.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        ImageView btnPerfil = findViewById(R.id.btnPerfil);
        btnPerfil.setOnClickListener(v -> {
            Intent it = new Intent(SenhaActivity.this, PerfilActivity.class);
            it.putExtra("usuarioEmail", usuarioEmailLogado);
            startActivity(it);
        });

        carregarSenhas();

        botaoAdicionar.setOnClickListener(v -> mostrarDialogCadastroOuEdicao(null));
    }

    private void carregarSenhas() {
        containerCards.removeAllViews();
        List<Senha> senhas = bancoDAO.listarSenhas(usuarioEmailLogado);
        LayoutInflater inflater = LayoutInflater.from(this);

        for (Senha s : senhas) {
            View card = inflater.inflate(R.layout.item_card_senha, containerCards, false);
            TextView txtNome     = card.findViewById(R.id.txtNome);
            TextView txtSenha    = card.findViewById(R.id.txtSenha);
            ImageView btnVer     = card.findViewById(R.id.btnVerSenha);
            ImageView btnExcluir = card.findViewById(R.id.btnExcluir);
            ImageView btnEditar  = card.findViewById(R.id.btnEditar);

            txtNome.setText(s.getNome());
            txtSenha.setText("••••••••");

            final boolean[] visivel = {false};
            btnVer.setOnClickListener(v -> {
                visivel[0] = !visivel[0];
                if (visivel[0]) {
                    txtSenha.setText(s.getSenha());
                    btnVer.setImageResource(R.drawable.eye);
                } else {
                    txtSenha.setText("••••••••");
                    btnVer.setImageResource(R.drawable.eyeoff);
                }
            });

            btnExcluir.setOnClickListener(v -> confirmarDelete(s));
            btnEditar.setOnClickListener(v -> mostrarDialogCadastroOuEdicao(s));

            containerCards.addView(card);
        }
    }

    private void mostrarDialogCadastroOuEdicao(Senha senhaExistente) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_senha, null);
        builder.setView(view);

        EditText editNome  = view.findViewById(R.id.editNomeDialog);
        EditText editSenha = view.findViewById(R.id.editSenhaDialog);

        if (senhaExistente != null) {
            editNome.setText(senhaExistente.getNome());
            editNome.setEnabled(false);
            editSenha.setText(senhaExistente.getSenha());
        }

        builder.setPositiveButton("Salvar", null);
        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String nome       = editNome.getText().toString().trim();
            String senhaTexto = editSenha.getText().toString().trim();

            if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(senhaTexto)) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean sucesso;
            if (senhaExistente == null) {
                Senha nova = new Senha(0, nome, senhaTexto, usuarioEmailLogado);
                sucesso = bancoDAO.inserirSenha(nova);
                if (!sucesso) {
                    Toast.makeText(this, "Erro ao salvar senha!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this, "Senha salva!", Toast.LENGTH_SHORT).show();
            } else {
                sucesso = bancoDAO.atualizarSenha(senhaExistente.getId(), senhaTexto);
                if (!sucesso) {
                    Toast.makeText(this, "Erro ao atualizar senha!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this, "Senha atualizada!", Toast.LENGTH_SHORT).show();
            }

            carregarSenhas();
            dialog.dismiss();
        });
    }

    private void confirmarDelete(Senha senha) {
        new AlertDialog.Builder(this)
                .setTitle("Excluir senha")
                .setMessage("Deseja excluir \"" + senha.getNome() + "\"?")
                .setPositiveButton("Sim", (dialog, which) -> {
                    boolean excluiu = bancoDAO.deletarSenha(senha.getId());
                    if (excluiu) {
                        Toast.makeText(this, "Senha excluída", Toast.LENGTH_SHORT).show();
                        carregarSenhas();
                    } else {
                        Toast.makeText(this, "Erro ao excluir senha", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Não", null)
                .show();
    }
}
