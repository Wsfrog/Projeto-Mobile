package com.example.sistemateste;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private BancoDAO bancoDAO;
    private EditText entradaEmail, entradaSenha;
    private Button btnEntrar;
    private TextView textoCadastro; // Novo: referência para o link de cadastro

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bancoDAO = new BancoDAO(this);

        entradaEmail = findViewById(R.id.entrada_email);
        entradaSenha = findViewById(R.id.entrada_senha);
        btnEntrar = findViewById(R.id.botao_entrar);
        textoCadastro = findViewById(R.id.texto_cadastro); // Novo

        btnEntrar.setOnClickListener(v -> {
            String email = entradaEmail.getText().toString().trim();
            String senha = entradaSenha.getText().toString();

            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            Usuario user = bancoDAO.buscarUsuario(email);
            if (user != null && user.getSenha().equals(senha)) {
                Intent intent = new Intent(LoginActivity.this, SenhaActivity.class);
                intent.putExtra("emailUsuario", email);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Usuário ou senha incorretos", Toast.LENGTH_SHORT).show();
            }
        });

        // Novo: Ação de clique para abrir CadastroActivity
        textoCadastro.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, CadastrarActivity.class);
            startActivity(intent);
        });
    }
}
