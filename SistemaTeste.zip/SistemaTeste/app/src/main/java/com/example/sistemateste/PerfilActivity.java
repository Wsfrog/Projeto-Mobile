package com.example.sistemateste;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class PerfilActivity extends AppCompatActivity {

    private BancoDAO bancoDAO;
    private EditText editNome, editEmail, editSenha;
    private Button btnSalvar, btnExcluirConta, btnLogout;

    private Usuario usuarioAtual;
    private String emailOriginal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        bancoDAO = new BancoDAO(this);

        // Referência aos campos e botões do layout
        editNome = findViewById(R.id.editNome);
        editEmail = findViewById(R.id.editEmail);
        editSenha = findViewById(R.id.editSenha);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnExcluirConta = findViewById(R.id.btnExcluirConta);
        btnLogout = findViewById(R.id.btnLogout);

        // Recebe email original do intent (usuário logado)
        emailOriginal = getIntent().getStringExtra("usuarioEmail");
        if (emailOriginal == null || emailOriginal.isEmpty()) {
            Toast.makeText(this, "Erro: usuário não identificado.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        carregarDadosUsuario();

        btnSalvar.setOnClickListener(v -> salvarAlteracoes());
        btnExcluirConta.setOnClickListener(v -> confirmarExcluirConta());
        btnLogout.setOnClickListener(v -> fazerLogout());
    }

    private void carregarDadosUsuario() {
        usuarioAtual = bancoDAO.buscarUsuario(emailOriginal);
        if (usuarioAtual != null) {
            editNome.setText(usuarioAtual.getNome());
            editEmail.setText(usuarioAtual.getEmail());
            editSenha.setText(""); // deixa vazio para segurança
        } else {
            Toast.makeText(this, "Usuário não encontrado.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private boolean emailJaExiste(String email) {
        if (email.equals(emailOriginal)) return false; // mesmo email, ok
        Usuario u = bancoDAO.buscarUsuario(email);
        return u != null;
    }

    private void salvarAlteracoes() {
        String novoNome = editNome.getText().toString().trim();
        String novoEmail = editEmail.getText().toString().trim();
        String novaSenhaInput = editSenha.getText().toString();

        if (novoNome.isEmpty() || novoEmail.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (emailJaExiste(novoEmail)) {
            Toast.makeText(this, "Este email já está em uso por outro usuário.", Toast.LENGTH_SHORT).show();
            return;
        }

        String senhaParaAtualizar = novaSenhaInput.isEmpty() ? usuarioAtual.getSenha() : novaSenhaInput;

        boolean sucesso = bancoDAO.atualizarUsuario(emailOriginal, novoNome, novoEmail, senhaParaAtualizar);

        if (sucesso) {
            Toast.makeText(this, "Dados atualizados!", Toast.LENGTH_SHORT).show();
            emailOriginal = novoEmail;
            usuarioAtual = bancoDAO.buscarUsuario(emailOriginal);
            editSenha.setText("");
        } else {
            Toast.makeText(this, "Erro ao atualizar dados!", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmarExcluirConta() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir Conta")
                .setMessage("Tem certeza que deseja excluir sua conta? Esta ação não pode ser desfeita.")
                .setPositiveButton("Sim", (dialog, which) -> {
                    boolean excluiu = bancoDAO.deletarUsuario(emailOriginal);
                    if (excluiu) {
                        Toast.makeText(this, "Conta excluída com sucesso.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(PerfilActivity.this, LoginActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "Erro ao excluir conta.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Não", null)
                .show();
    }

    private void fazerLogout() {
        Toast.makeText(this, "Logout realizado.", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(PerfilActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
